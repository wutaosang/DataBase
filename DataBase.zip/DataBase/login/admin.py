# from django.contrib import admin
# from login.models import user
#将所用到的model进行注入操作
from django.contrib import admin
from .models import Article
from .models import TDepartment


class ArticleAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'created_time',)
    list_display_links = ('title',)


class TDepartmentAdmin(admin.ModelAdmin):
    list_display = ('dcode', 'dname', 'dnumber', 'minimum_wage')


admin.site.register(Article, ArticleAdmin)
admin.site.register(TDepartment, TDepartmentAdmin)

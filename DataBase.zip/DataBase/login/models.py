from django.db import models
from django.db.models.signals import post_save, post_delete, pre_delete
from django.dispatch import receiver
from django.db import connection
# Create your models here.


# class Permission(models.Model):
#     class Meta:
#         #权限信息，这里定义的权限的名字，后面是描述信息，描述信息是在django admin中显示权限用的
#         permissions = (
#             ('views_slg_users_tem', '查看玩家管理'),
#             ('views_slg_alliance_tem', '查看联盟管理'),
#             ('views_slg_mail_notice_tem', '查看公告邮件'),
#             ('views_slg_order_tem', '查看订单系统'),
#             ('views_slg_reward_tem', '查看礼包奖励'),
#             ('views_slg_service_reply_tem', '查看客服反馈'),
#             ('views_slg_user_log_tem', '查看玩家日志'),
#             ('views_slg_server_tem', '查看服务器管理'),
#             ('views_slg_manager_tem', '查看管理员管理'),
#         )


class UserInfo(models.Model):
    name = models.CharField(max_length=16)
    password = models.CharField(max_length=24)
    permission_delete = models.IntegerField(blank=False)
    permission_add = models.IntegerField(blank=False)
    permission_update = models.IntegerField(blank=False)
    is_superuser = models.IntegerField(blank=False, default=0)

class Article(models.Model):
    title = models.CharField('标题', max_length=70)
    body = models.TextField('内容', max_length=200, blank=True)
    created_time = models.DateTimeField('发布时间')

    class Meta:
        verbose_name = '文章'
        verbose_name_plural = '文章'

    def __str__(self):
        return self.title


class TAccount(models.Model):
    # acc_id = models.IntegerField(primary_key = True)
    acc_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    password = models.CharField(max_length=20)
    permission_delete = models.IntegerField(blank=False, default=0)
    permission_add = models.IntegerField(blank=False, default=0)
    permission_update = models.IntegerField(blank=False, default=0)
    is_superuser = models.IntegerField(blank=False, default=0)


class TDepartment(models.Model):
    dcode = models.AutoField(primary_key=True)
    dname = models.CharField(max_length=20, blank=False)
    # minimum_wage = models.DecimalField(max_digits=12, decimal_places=3)
    minimum_wage = models.FloatField(blank=False)
    dnumber = models.IntegerField()  # 部门人数

    def __str__(self):
        return ("department name: " + self.dname)


class TStaff(models.Model):
    scode = models.AutoField(primary_key=True)
    sname = models.CharField(max_length=20, blank=False)
    sgender = models.CharField(max_length=2)
    sage = models.IntegerField()
    dcode = models.ForeignKey(TDepartment, on_delete=models.CASCADE)

    def __str__(self):
        return("staff name: " + self.sname)


# @receiver(pre_delete, sender=TStaff)
# def before_delete_blog(sender, instance, **kwargs):
#     with connection.cursor() as cursor:
#         cursor.execute("update login_tdepartment set dnumber=dnumber-1 where dcode={}".format(instance.dcode.dcode))
#         print('触发器实现！')
#     print(instance.sname + " has been deleted ")


class TAttendance(models.Model):
    id = models.AutoField(primary_key=True)
    scode = models.ForeignKey(TStaff, on_delete=models.CASCADE)
    ayear = models.IntegerField(blank=False)
    amonth = models.IntegerField(blank=False)
    absent_num = models.IntegerField()

    class Meta:
        unique_together = ('scode', 'ayear', 'amonth')

    def __str__(self):
        string = "id:"+str(self.id)+" "
        return string


class WorkType(models.Model):
    w_id = models.AutoField(primary_key=True)
    w_type = models.CharField(blank=False, max_length=20)
    mul = models.FloatField(blank=False)

    def __str__(self):
        string = "加班类型：" + self.w_type
        return string


class Wage(models.Model):
    id = models.AutoField(primary_key=True)
    scode = models.ForeignKey(TStaff, on_delete=models.CASCADE)
    w_year = models.IntegerField(blank=False)
    w_month = models.IntegerField(blank=False)
    w_num = models.IntegerField(blank=False)
    w_id = models.ForeignKey(WorkType, on_delete=models.CASCADE)
    wage = models.FloatField(blank=False)
    class Meta:
        unique_together = ('scode', 'w_year', 'w_month', 'w_id')

    def __str__(self):
        string = "scode" + str(self.scode)
        return string


class Salary(models.Model):
    id = models.AutoField(primary_key=True)
    scode = models.ForeignKey(TStaff, on_delete=models.CASCADE)
    s_year = models.IntegerField(blank=False)
    s_month = models.IntegerField(blank=False)
    sw = models.FloatField(blank=False)
    salary = models.FloatField(blank=False)

    class Meta:
        unique_together = ('scode', 's_year', 's_month')

    def __str__(self):
        string = 'scode:' +str(self.scode)
        return string


class YearSalay(models.Model):
    id = models.AutoField(primary_key=True)
    scode = models.ForeignKey(TStaff, on_delete=models.CASCADE)
    year = models.IntegerField(blank=False)
    sumSalary = models.IntegerField(blank=False)
    def __str__(self):
        string = 'scode:' + str(self.scode)
        return string

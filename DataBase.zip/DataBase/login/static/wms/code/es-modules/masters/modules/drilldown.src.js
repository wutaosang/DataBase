/**
 * @license Highcharts JS v9.1.1 (2021-06-03)
 * @module highcharts/modules/drilldown
 * @requires highcharts
 *
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../Extensions/Drilldown.js';

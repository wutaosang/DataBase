/**
 * @license Highcharts JS v9.1.1 (2021-06-03)
 * @module highcharts/modules/venn
 * @requires highcharts
 *
 * (c) 2017-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Venn/VennSeries.js';

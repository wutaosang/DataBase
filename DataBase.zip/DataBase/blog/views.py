from django.shortcuts import render, HttpResponse
from blog import models

#
# def orm(requst):
#     # 增加一篇文章
#     models.Article.objects.create(title='增加标题一', created_time='2021-05-14 14:44:00.000')
#     return HttpResponse('orm')
# def orm(requst):
#     # 第一种方法：
#     # models.Article.objects.create(title='增加标题一', category_id=3, body='增加内容一', user_id=1)
#     # 第二种方法：添加数据，实例化表类，在实例化里传参为字段和值
#     obj = models.Article(title='增加标题二', created_time='2021-05-14 14:44:00.000', category_id=4, body='增加内容二')
#     # 写入数据库
#     obj.save()
#     # 第三种方法：将要写入的数据组合成字典，键为字段值为数据
#     dic = {'title': '增加标题三', 'category_id': '4', 'body': '增加内容三', 'created_time': '2021-05-14 14:44:00.000'}
#     # 添加到数据库，注意字典变量名称一定要加**
#     models.Article.objects.create(**dic)
#
#     return HttpResponse('orm')


def orm(requst):
    #获取所有文章，对应SQL：select * from Article
    all_article = models.Article.objects.all()
    print(all_article)
    return HttpResponse('orm')

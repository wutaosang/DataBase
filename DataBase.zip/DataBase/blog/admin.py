from django.contrib import admin
from .models import Article, Category, Tags


class ArticleAdmin(admin.ModelAdmin):
    list_display = ('id', 'category_id', 'body', 'body', 'title', 'created_time',)
    list_display_links = ('title',)


class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', "name")
    list_display_links = ('id',)


admin.site.register(Article, ArticleAdmin)
admin.site.register(Category, CategoryAdmin)
